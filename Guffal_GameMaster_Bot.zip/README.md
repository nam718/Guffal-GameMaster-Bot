# Guffal GameMaster Bot

This is a custom Discord bot designed for the Guffal gaming community. The bot includes features to enhance gaming experiences, including game management, player stats, and more.

## Features
- Game scheduling
- Player leaderboard tracking
- Fun community interactions

## Setup
1. Install Python 3.9 or above.
2. Run `pip install -r requirements.txt` to install dependencies.
3. Add your Discord bot token to the `.env` file.
4. Run the bot using `python bot.py`.

## License
MIT License.